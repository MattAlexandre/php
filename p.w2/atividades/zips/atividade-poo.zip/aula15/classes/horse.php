<?php

require_once 'class-animails.php';


class horse  extends 'class-anamails.php'
{

  public function gettrota()
  {
     return ' pocoto pocoto ';
  }

  public function toString()
  {
    echo ' pet-shop';

    echo ' name:        '.$this->getName();
    echo ' specie:      '.$this->getSpecies();
    echo ' breed:       '.$this->getBreed();
    echo ' size :       '.$this->getSize();
    echo ' birthdate:   '.$this->getBirthdate();
    echo ' genre:       '.$this->getGenre();
    echo ' namme_owner: '.$this->getName_owner();
    echo ' contact:     '.$this->getContact();
    echo ' weight:      '.$this->getWeight();

    echo ' metd - animal'

    echo $this->gettrota();

  }

}
