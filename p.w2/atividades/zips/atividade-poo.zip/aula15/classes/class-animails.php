<?php

require_once 'process.php';

class  pets()
{ 
    private $name;           //nome
    private $epecie;         //especie  
    private $breed;         
    private $size;
    private $birthdate;
    private $genre;
    private $name_owner;
    private $contact;
    private $Weigh;

     // var-close..
     
     //name
     public function setName($name)
     {
        $this->name = $name;
     }
     
     public function getName()
     {
         return $this->name;
     }
    
     //especies
     public function setSpecies($species)
     {
        $this->species = $species;
     }
     
     public function getSpecies()
     {
         return $this->species;
     }

     //breed
     public function setBreed($breed)
     {
        $this->breed = $breed;
     }
     
     public function getBreed()
     {
         return $this->breed;
     }

     //size
     public function setSize($size)
     {
        $this->size = $size;
     }
     
     public function getSize()
     {
         return $this->size;
     }

     //birthdate
     public function setBirthDate($birthdate)
     {
        $this->birthdate = $birthdate;
     }
     
     public function getBirthDate()
     {
         return $this->birthdate;
     }

     //genre
     public function setGenre($genre)
     {
        $this->genre = $genre;
     }
     
     public function getGenre()
     {
         return $this->genre;
     }

     //name_owner
     public function setName_owner($name_owner)
     {
        $this->name_owver = $name_owner;
     }
     
     public function getName_owner()
     {
         return $this->name_owver;
     }

     //contact
     public function setContact($contact)
     {
        $this->contact = $contact;
     }
     
     public function getContact()
     {
         return $this->contact;
     }

     //weight
     public function setWight($Weight)
     {
        $this->weight = $Weight;
     }
     
     public function getWeight()
     {
         return $this->weight;
     }

     public function setIdade($birthdate)
     {
         $birthdayoDateTime = new DateTime($this->birthDay);
         $date = new DateTime();
         $age =  $birthdayoDateTime->diff($date);
         
     }
     public function getIdade()
     {
        return $age->y;
     }
 
}

