<?php

    //dados gerais

    $name = $_GET = ['name'];              
    $species = $_GET = ['species'];        
    $breed = $_GET = ['breed'];
    $size = $_GET = ['size'];
    $birthdate = $_GET = ['birthdate'];
    $genre = $_GET = ['genre'];
    $name_owner = $_GET = ['name_owner'];
    $contact = $_GET = ['contact'];
    $Weight = $_GET = ['Weight'];



    // instanciamento 

    
    //setando os dados no set


    //Setando os Dados no - SET
     $animails->setName($name);
     $animails->setSpecies($species);
     $animails->setBreed($breed);
     $animails->setSize($size);
     $animails->setBirthDate($birthdate);
     $animails->setGenre($genre);
     $animails->setName_owner($name_owner);
     $animails->setContact($contact);
     $animails->SetWeight($Weight);

     
     switch ($species){
         case 'dog':

            $dog = new dog();

            $dog->setName($name);
            $dog->setSpecies($species);
            $dog->setBreed($breed);
            $dog->setSize($size);
            $dog->setBirthDay($birthdate);
            $dog->setGenre($genre);
            $dog->setName_owner($name_owner);
            $dog->setContact($contact);
            $dog->SetWeight($Weight);

            $dog->toString();

            break;

        case 'cat':
            $cat = new cat();

            $cat->setName($name);
            $cat->setSpecies($species);
            $cat->setBreed($breed);
            $cat->setSize($size);
            $cat->setBirthDay($birthdate);
            $cat->setGenre($genre);
            $cat->setName_owner($name_owner);
            $cat->setContact($contact);
            $cat->SetWeight($Weight);

            $cat->toString();               //class;
            break;

        case 'parrot':
            $parrot = new parrot();

            $parrot->setName($name);
            $parrot->setSpecies($species);
            $parrot->setBreed($breed);
            $parrot->setSize($size);
            $parrot->setBirthDay($birthdate);
            $parrot->setGenre($genre);
            $parrot->setName_owner($name_owner);
            $parrot->setContact($contact);
            $parrot->SetWeight($Weight);

            $parrot->toString();      //class;
            break;
                
        case 'hamster':
            $hamster = new hamster();

            $hamster->setName($name);
            $hamster->setSpecies($species);
            $hamster->setBreed($breed);
            $hamster->setSize($size);
            $hamster->setBirthDay($birthdate);
            $hamster->setGenre($genre);
            $hamster->setName_owner($name_owner);
            $hamster->setContact($contact);
            $hamster->SetWeight($Weight);

            $hamster->toString();         //class;
            break;

        case 'ferrat':
            $ferrat = new ferrat();

            $ferrat->setName($name);
            $ferrat->setSpecies($species);
            $ferrat->setBreed($breed);
            $ferrat->setSize($size);
            $ferrat->setBirthDay($birthdate);
            $ferrat->setGenre($genre);
            $ferrat->setName_owner($name_owner);
            $ferrat->setContact($contact);
            $ferrat->SetWeight($Weight);

            $dog->toString();          //class;
            break;
                    
        case 'snake':
            $snake = new snake();

            $snake->setName($name);
            $snake->setSpecies($species);
            $snake->setBreed($breed);
            $snake->setSize($size);
            $snake->setBirthDay($birthdate);
            $snake->setGenre($genre);
            $snake->setName_owner($name_owner);
            $snake->setContact($contact);
            $snake->SetWeight($Weight);

            $snake->toString();          //class;
            break;

        case 'chamaleon':
            $chamaleon = new chamaleon();

            $chamaleon->setName($name);
            $chamaleon->setSpecies($species);
            $chamaleon->setBreed($breed);
            $chamaleon->setSize($size);
            $chamaleon->setBirthDay($birthdate);
            $chamaleon->setGenre($genre);
            $chamaleon->setName_owner($name_owner);
            $chamaleon->setContact($contact);
            $chamaleon->SetWeight($Weight);

            $chamaleon->toString();         //class;
            break;
    
        case 'horse':
            $horse = new horse();

            $horse->setName($name);
            $horse->setSpecies($species);
            $horse->setBreed($breed);
            $horse->setSize($size);
            $horse->setBirthDay($birthdate);
            $horse->setGenre($genre);
            $horse->setName_owner($name_owner);
            $horse->setContact($contact);
            $horse->SetWeight($Weight);

            $horse->toString();            //class;
            break;
    
        case 'bearded dragon':
            $bearded_dragon = new bearded_dragon();

            $bearded_dragon->setName($name);
            $bearded_dragon->setSpecies($species);
            $bearded_dragon->setBreed($breed);
            $bearded_dragon->setSize($size);
            $bearded_dragon->setBirthDay($birthdate);
            $bearded_dragon->setGenre($genre);
            $bearded_dragon->setName_owner($name_owner);
            $bearded_dragon->setContact($contact);
            $bearded_dragon->SetWeight($Weight);

            $bearded_dragon->toString();  //class;
            break;
                    
        case 'bunny':
            $bunny = new bunny();

            $bunny->setName($name);
            $bunny->setSpecies($species);
            $bunny->setBreed($breed);
            $bunny->setSize($size);
            $bunny->setBirthDay($birthdate);
            $bunny->setGenre($genre);
            $bunny->setName_owner($name_owner);
            $bunny->setContact($contact);
            $bunny->SetWeight($Weight);

            $bunny->toString();            //class;
             break;
    
            
     }






/* IDADE CAL */

/* 

//var

var idade, nas_p, ano_at;


//browser1

 var = parsetInt(prompt(" digite a vossa idade: "));
 var = parseInt(prompt(" digite o ano atual: "));

//cont
 
idade = nas - ano_at;

//browser-f

document.write(" a sua idade é: ${idade} ");



*/ 

?>

